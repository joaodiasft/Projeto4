package br.com.projetoads4.projetointegrador;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProjetointegradorApplicationTests {

	@Test
	void contextLoads() {
	}

}
