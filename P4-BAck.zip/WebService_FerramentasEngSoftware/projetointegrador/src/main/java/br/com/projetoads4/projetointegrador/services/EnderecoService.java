package br.com.projetoads4.projetointegrador.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import br.com.projetoads4.projetointegrador.domain.Endereco;

import br.com.projetoads4.projetointegrador.error.NotFoundException;
import br.com.projetoads4.projetointegrador.repository.EnderecoRepository;


@Service
public class EnderecoService {


    @Autowired
    private EnderecoRepository repository;

    public Endereco findById(Long id) {
        return repository.findById(id).orElseThrow(() -> new NotFoundException("Endereço não encontrado"));
    }

    public List<Endereco> findAll() {
        return repository.findAll();
    }

    public void save(Endereco endereco) {
        repository.save(endereco);
    }

    public void update(Endereco endereco) {
        repository.saveAndFlush(endereco);
    }

    public void delete(Long id) {
        if(! repository.existsById(id))
             throw new NotFoundException("Endereço não encontrado");
        repository.deleteById(id);
    }



    
}
