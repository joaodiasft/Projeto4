package br.com.projetoads4.projetointegrador.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import br.com.projetoads4.projetointegrador.domain.Categoria;
import br.com.projetoads4.projetointegrador.error.NotFoundException;
import br.com.projetoads4.projetointegrador.repository.CategoriaRepository;

@Service
public class CategoriaService {


    @Autowired
    private CategoriaRepository repository;

    public Categoria findById(Long id) {
        return repository.findById(id).orElseThrow(() -> new NotFoundException("Categoria não encontrada"));
    }

    public List<Categoria> findAll() {
        return repository.findAll();
    }

    public void save(Categoria categoria) {
        repository.save(categoria);
    }

    public void update(Categoria categoria) {
        repository.saveAndFlush(categoria);
    }

    public void delete(Long id) {
        if(! repository.existsById(id))
        throw new NotFoundException("Cliente não encontrado");
        repository.deleteById(id);
    }



    
}
