package br.com.projetoads4.projetointegrador.domain.dto;

import br.com.projetoads4.projetointegrador.domain.Categoria;

public class CategoriaDTO {

    private long id;
    private String nome;

    
    public CategoriaDTO(Categoria categoria) {
        this.id = categoria.getId();
        this.nome = categoria.getNome();

    }

    public long getId() {
        return id;
    }
    public void setId(long id) {
        this.id = id;
    }
    public String getNome() {
        return nome;
    }
    public void setNome(String nome) {
        this.nome = nome;
    }

}
