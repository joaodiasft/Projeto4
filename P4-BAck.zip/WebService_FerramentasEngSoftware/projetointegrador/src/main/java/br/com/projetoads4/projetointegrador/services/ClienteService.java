package br.com.projetoads4.projetointegrador.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;

import br.com.projetoads4.projetointegrador.domain.Cliente;
import br.com.projetoads4.projetointegrador.error.NotFoundException;
import br.com.projetoads4.projetointegrador.repository.ClienteRepository;

@Service
public class ClienteService {


    @Autowired
    private BCryptPasswordEncoder passwordEncoder;

    @Autowired
    private ClienteRepository repository;

    public Cliente findById(Long id) {
        return repository.findById(id).orElseThrow(() -> new NotFoundException("Cliente não encontrado"));
    }

    public List<Cliente> findAll() {
        return repository.findAll();
    }

    public void save(Cliente cliente) {
        String senha = cliente.getSenha();
        cliente.setSenha(passwordEncoder.encode(senha));
        repository.save(cliente);
    }

    public void update(Cliente cliente) {
        repository.saveAndFlush(cliente);
    }

    public void delete(Long id) {
        if(! repository.existsById(id))
             throw new NotFoundException("Cliente não encontrado");
        repository.deleteById(id);
    }



    
}
