package br.com.projetoads4.projetointegrador.configuration.security;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import br.com.projetoads4.projetointegrador.domain.Cliente;
import br.com.projetoads4.projetointegrador.repository.ClienteRepository;

@Service
public class UserSecurityService implements UserDetailsService {

    @Autowired
    private ClienteRepository clienteRepository;

    @Override
    public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
        Cliente cliente = clienteRepository.findByUsername(username);
        if(cliente == null)
            throw new BadCredentialsException("UserName Inválido");
        
        return new UserSecurity(cliente);

    }
    
}
