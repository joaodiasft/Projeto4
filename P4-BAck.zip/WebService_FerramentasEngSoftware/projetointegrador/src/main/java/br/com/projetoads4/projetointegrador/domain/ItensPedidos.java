package br.com.projetoads4.projetointegrador.domain;


import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.validation.constraints.NotNull;




@Entity
public class ItensPedidos {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private long id;

    @NotNull(message = "Campo Obrigatório")
    private String quantidade;

    
    @NotNull(message = "Campo Obrigatório")
    private String valor;
    
    
    public ItensPedidos() {
    }

    public ItensPedidos(long id, String quantidade, String valor) {
        this.id = id;
        this.quantidade = quantidade;
        this.valor = valor;
        
        
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getQuantidade() {
        return quantidade;
    }

    public void setQuantidade(String quantidade) {
        this.quantidade = quantidade;
    }

    public String getValor() {
        return valor;
    }

    public void setValor(String valor) {
        this.valor = valor;
    }


    
}
