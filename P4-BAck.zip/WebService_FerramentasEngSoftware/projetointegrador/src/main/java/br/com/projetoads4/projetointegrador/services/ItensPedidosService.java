package br.com.projetoads4.projetointegrador.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import br.com.projetoads4.projetointegrador.domain.ItensPedidos;
import br.com.projetoads4.projetointegrador.error.NotFoundException;
import br.com.projetoads4.projetointegrador.repository.ItensPedidosRepository;

@Service
public class ItensPedidosService {


    @Autowired
    private ItensPedidosRepository repository;

    public ItensPedidos findById(Long id) {
        return repository.findById(id).orElseThrow(() -> new NotFoundException("Itens Pedidos não encontrado"));
    }

    public List<ItensPedidos> findAll() {
        return repository.findAll();
    }

    public void save(ItensPedidos itensPedidos) {
        repository.save(itensPedidos);
    }

    public void update(ItensPedidos itensPedidos) {
        repository.saveAndFlush(itensPedidos);
    }

    public void delete(Long id) {
        if(! repository.existsById(id))
             throw new NotFoundException("Itens Pedidos não encontrado");
        repository.deleteById(id);
    }



    
}
