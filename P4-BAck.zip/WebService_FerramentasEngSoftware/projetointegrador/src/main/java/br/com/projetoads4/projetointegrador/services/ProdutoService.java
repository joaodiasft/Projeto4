package br.com.projetoads4.projetointegrador.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import br.com.projetoads4.projetointegrador.domain.Produto;
import br.com.projetoads4.projetointegrador.error.NotFoundException;
import br.com.projetoads4.projetointegrador.repository.ProdutoRepository;

@Service
public class ProdutoService {


    @Autowired
    private ProdutoRepository repository;

    public Produto findById(Long id) {
        return repository.findById(id).orElseThrow(() -> new NotFoundException("Produto não encontrado"));
    }

    public List<Produto> findAll() {
        return repository.findAll();
    }

    public void save(Produto produto) {
        repository.save(produto);
    }

    public void update(Produto produto) {
        repository.saveAndFlush(produto);
    }

    public void delete(Long id) {
        if(! repository.existsById(id))
             throw new NotFoundException("Cliente não encontrado");
        repository.deleteById(id);
    }



    
}
