package br.com.projetoads4.projetointegrador.domain;

import java.util.List;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.validation.constraints.NotNull;


import javax.persistence.JoinColumn;

@Entity
public class Categoria {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private long id;

    @NotNull(message = "Campo Obrigatório")
    private String nome;

    @ManyToMany
    @JoinTable(
     name = "categoria_produto", 
     joinColumns = @JoinColumn(name = "categoria_id"), 
     inverseJoinColumns = @JoinColumn(name = "produto_id"))
    private List<Produto> produtos;

    public Categoria() {

    }

    public Categoria(long id, String nome) {
        this.id = id;
        this.nome = nome;
    }
    public long getId() {
        return id;
    }
    public void setId(long id) {
        this.id = id;
    }
    public String getNome() {
        return nome;
    }
    public void setNome(String nome) {
        this.nome = nome;
    }

    public List<Produto> getProdutos() {
        return produtos;
    }

    public void setProdutos(List<Produto> produtos) {
        this.produtos = produtos;
    }
    
}
