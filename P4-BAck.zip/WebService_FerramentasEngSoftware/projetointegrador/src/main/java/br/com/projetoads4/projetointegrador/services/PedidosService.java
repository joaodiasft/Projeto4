package br.com.projetoads4.projetointegrador.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import br.com.projetoads4.projetointegrador.domain.Pedidos;
import br.com.projetoads4.projetointegrador.error.NotFoundException;
import br.com.projetoads4.projetointegrador.repository.PedidosRepository;

@Service
public class PedidosService {


    @Autowired
    private PedidosRepository repository;

    public Pedidos findById(Long id) {
        return repository.findById(id).orElseThrow(() -> new NotFoundException("Pedido não encontrado"));
    }

    public List<Pedidos> findAll() {
        return repository.findAll();
    }

    public void save(Pedidos pedidos) {
        repository.save(pedidos);
    }

    public void update(Pedidos pedidos) {
        repository.saveAndFlush(pedidos);
    }

    public void delete(Long id) {
        if(! repository.existsById(id))
             throw new NotFoundException("Pedido não encontrado");
        repository.deleteById(id);
    }



    
}
