package br.com.projetoads4.projetointegrador.domain.dto;

import br.com.projetoads4.projetointegrador.domain.Produto;

public class ProdutoDTO {
    private long id;
    private String nome;
    double preco;

    
    public ProdutoDTO(Produto produto) {
        this.id = produto.getId();
        this.nome = produto.getNome();
        this.preco = produto.getPreco();
    }

    public long getId() {
        return id;
    }
    public void setId(long id) {
        this.id = id;
    }
    public String getNome() {
        return nome;
    }
    public void setNome(String nome) {
        this.nome = nome;
    }
    public double getPreco() {
        return preco;
    }
    public void setPreco(double preco) {
        this.preco = preco;
    }

    
}
