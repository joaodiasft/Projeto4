package br.com.projetoads4.projetointegrador.error;



import java.util.HashMap;

import javax.servlet.http.HttpServletRequest;


import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

@RestControllerAdvice
public class ErrorAdvice {
    
    @ExceptionHandler(NotFoundException.class)
    public ResponseEntity<ApiError> handlerNotFoundException(NotFoundException exception, HttpServletRequest request){
        ApiError apiError = new ApiError(HttpStatus.NOT_FOUND.value(), exception.getMessage(),request.getRequestURI());
        return new ResponseEntity<ApiError>(apiError, HttpStatus.NOT_FOUND);
    }
    @ExceptionHandler(MethodArgumentNotValidException.class)
    public ResponseEntity<ApiError> handlerMethodArgumentNotValidException(MethodArgumentNotValidException exception, HttpServletRequest request){
       
        HashMap<String,String> listadeErros = new HashMap<>();
        for(FieldError error : exception.getFieldErrors()){
            listadeErros.put(error.getField(), error.getDefaultMessage());
        }


        ApiError apiError = new ApiError(HttpStatus.BAD_REQUEST.value(), "Campos Inválidos",request.getRequestURI());
        apiError.setListadeErros(listadeErros);
        return new ResponseEntity<ApiError>(apiError, HttpStatus.BAD_REQUEST);
    }
    

    @ExceptionHandler(EmptyResultDataAccessException.class)
    public ResponseEntity<ApiError> handlerEmptyResultDataAccessException(EmptyResultDataAccessException exception, HttpServletRequest request){
        ApiError apiError = new ApiError(HttpStatus.NOT_FOUND.value(), exception.getMessage(),request.getRequestURI());
        return new ResponseEntity<ApiError>(apiError, HttpStatus.NOT_FOUND);
    }
}
