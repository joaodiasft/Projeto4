package br.com.projetoads4.projetointegrador.error;

public class NotFoundException extends RuntimeException{

    public NotFoundException(String message) {
        super(message);
    }
    
}
