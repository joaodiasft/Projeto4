package br.com.projetoads4.projetointegrador.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import br.com.projetoads4.projetointegrador.domain.Cliente;

@Repository
public interface ClienteRepository extends JpaRepository<Cliente,Long>{

    public Cliente findByUsername(String username);
}
