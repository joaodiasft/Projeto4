package br.com.projetoads4.projetointegrador.error;

import java.util.Date;
import java.util.HashMap;

public class ApiError {
    
    private long timestamp;
    private int status;
    private String message;
    private String path;

    private HashMap<String,String> listadeErros;
    
    public ApiError(int status, String message, String path) {
        this.status = status;
        this.message = message;
        this.path = path;
        this.timestamp = new Date().getTime();
    }
    public long getTimestamp() {
        return timestamp;
    }
    public void setTimestamp(long timestamp) {
        this.timestamp = timestamp;
    }
    public int getStatus() {
        return status;
    }
    public void setStatus(int status) {
        this.status = status;
    }
    public String getMessage() {
        return message;
    }
    public void setMessage(String message) {
        this.message = message;
    }
    public String getPath() {
        return path;
    }
    public void setPath(String path) {
        this.path = path;
    }
    public HashMap<String, String> getListadeErros() {
        return listadeErros;
    }
    public void setListadeErros(HashMap<String, String> listadeErros) {
        this.listadeErros = listadeErros;
    }

    
}
