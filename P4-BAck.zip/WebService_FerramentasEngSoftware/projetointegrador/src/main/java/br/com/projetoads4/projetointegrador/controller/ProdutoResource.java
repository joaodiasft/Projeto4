package br.com.projetoads4.projetointegrador.controller;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import br.com.projetoads4.projetointegrador.domain.Produto;
import br.com.projetoads4.projetointegrador.domain.dto.ProdutoDTO;
import br.com.projetoads4.projetointegrador.services.ProdutoService;


@RestController
@RequestMapping("/api/produtos/")
public class ProdutoResource {

    @Autowired
    private ProdutoService service;

    @GetMapping("/{id}")
    @ResponseStatus(value = HttpStatus.OK)
    public Produto obterPorId(@PathVariable("id") Long id){
        return service.findById(id);
    }
    @GetMapping("/")
    @ResponseStatus(value = HttpStatus.OK)
    public List<ProdutoDTO> obterTodos(){
        List<Produto> listaProduto = service.findAll();
        List<ProdutoDTO> listaProdutoDTO = new ArrayList<>();

        ProdutoDTO produtoDTO;

        for (Produto produto : listaProduto) {
             produtoDTO = new ProdutoDTO(produto);
             listaProdutoDTO.add(produtoDTO);
        }

        
        return listaProdutoDTO;
    }

    @PostMapping("/")
    @ResponseStatus(value = HttpStatus.CREATED)
    public void salvar(@RequestBody Produto produto, HttpServletRequest request, HttpServletResponse response){
        service.save(produto);
        response.setHeader("Location", request.getRequestURI()+produto.getId());
    }

    @PutMapping("/")
    @ResponseStatus(value = HttpStatus.NO_CONTENT)
    public void atualizar(@RequestBody Produto produto) {
        service.update(produto);
    }

    @DeleteMapping("/{id}")
    @ResponseStatus(value = HttpStatus.NO_CONTENT)
    public void deletar(@PathVariable("id") Long id){
        service.delete(id);
    }
    
}
