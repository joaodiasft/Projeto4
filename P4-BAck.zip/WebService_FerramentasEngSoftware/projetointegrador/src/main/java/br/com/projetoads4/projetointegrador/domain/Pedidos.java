package br.com.projetoads4.projetointegrador.domain;


import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.validation.constraints.NotNull;




@Entity
public class Pedidos {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private long id;

    @NotNull(message = "Campo Obrigatório")
    private String data;

    
    @NotNull(message = "Campo Obrigatório")
    private String total;
    
    
    @NotNull(message = "Campo Obrigatório")
    private String observacao;

    
    
    public Pedidos() {
    }

    public Pedidos(long id, String data, String total, String observacao) {
        this.id = id;
        this.data = data;
        this.total = total;
        this.observacao = observacao;
        
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getData() {
        return data;
    }

    public void setData(String data) {
        this.data = data;
    }

    public String getTotal() {
        return total;
    }

    public void setTotal(String total) {
        this.total = total;
    }

    public String getObservacao() {
        return observacao;
    }

    public void setObservacao(String observacao) {
        this.observacao = observacao;
    }

    
    

    

    
}
