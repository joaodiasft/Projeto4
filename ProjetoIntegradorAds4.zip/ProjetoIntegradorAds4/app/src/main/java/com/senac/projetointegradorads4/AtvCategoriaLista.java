package com.senac.projetointegradorads4;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListAdapter;
import android.widget.ListView;

import androidx.appcompat.app.AppCompatActivity;

import com.senac.projetointegradorads4.dao.CategoriaDao;
import com.senac.projetointegradorads4.model.Categoria;

import java.util.ArrayList;
import java.util.List;

public class AtvCategoriaLista extends AppCompatActivity implements View.OnClickListener, AdapterView.OnItemClickListener {

    ListView lstCategorias;
    Button btnInserir;

    List<Categoria> listaCategorias = new ArrayList<>();
    ListAdapter listAdapter;
    int indice;
    CategoriaDao categoriaDao;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.atv_categoria_lista);

        btnInserir = findViewById(R.id.btnInserir);
        btnInserir.setOnClickListener(this);

        lstCategorias = findViewById(R.id.lstCategorias);
        lstCategorias.setOnItemClickListener(this);

        categoriaDao = new CategoriaDao(this);
    }

    private void atualizarLista(){
        listaCategorias = categoriaDao.lista();
        listAdapter = new ArrayAdapter<Categoria>(this,android.R.layout.simple_list_item_1, listaCategorias);
        lstCategorias.setAdapter(listAdapter);
    }

    @Override
    protected void onResume() {
        super.onResume();
        atualizarLista();
    }

    @Override
    public void onClick(View v) {
        Categoria c = new Categoria();
        c.setId(0L);
        abrirCadastro("Inserir",c);
    }

    @Override
    public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
        indice = position;
        Categoria c = (Categoria) lstCategorias.getAdapter().getItem(position);
        abrirCadastro("Alterar", c);
    }

    private void abrirCadastro(String acao, Categoria c) {
        Intent telaCad = new Intent(this, com.senac.projetointegradorads4.AtvCategoriaCadastro.class);
        Bundle extras = new Bundle();
        extras.putString("acao",acao);
        extras.putSerializable("obj",c);
        telaCad.putExtras(extras);
        startActivity(telaCad);
    }
}