package com.senac.projetointegradorads4.dao;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import com.senac.projetointegradorads4.model.Categoria;
import com.senac.projetointegradorads4.model.Web_user;

import java.util.ArrayList;
import java.util.List;

public class Web_userDao {

    private final String TABELA = "webuser";
    private final String[] CAMPOS = {"id, senha, estado, username"};
    private Conexao conexao;
    private SQLiteDatabase banco;

    public Web_userDao(Context context){
        conexao = new Conexao(context);
        banco = conexao.getWritableDatabase();
    }

    private ContentValues preencherValores(Web_user web_user){
        ContentValues values = new ContentValues();
        values.put("senha", web_user.getSenha());
        values.put("estado", web_user.getEstado());
        values.put("username", web_user.getUsername());

        return values;
    }

    public long inserir(Web_user web_user){
        ContentValues values = preencherValores(web_user);
        return banco.insert(TABELA,null,values);
    }

    public long alterar(Web_user web_user){
        ContentValues values = preencherValores(web_user);
        return banco.update(TABELA,values,"id = ?", new String[]{String.valueOf(web_user.getLogin_id())});
    }

    public long excluir(Web_user web_user){
        return banco.delete(TABELA,"id = ?",new String[]{String.valueOf(web_user.getLogin_id())});
    }

    public List<Web_user> lista(){
        Cursor c = banco.query(TABELA,CAMPOS,null,null,null,null,null);
        List<Web_user> lista = new ArrayList<>();
        while (c.moveToNext()){
            Web_user web_user = new Web_user();
            web_user.setLogin_id(c.getLong(0));
            web_user.setSenha(c.getInt(1));
            web_user.setEstado(c.getString(2));
            web_user.setUsername(c.getString(3));
            lista.add(web_user);
        }
        return lista;
    }
}
