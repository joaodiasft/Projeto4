package com.senac.projetointegradorads4;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListAdapter;
import android.widget.ListView;

import androidx.appcompat.app.AppCompatActivity;

import com.senac.projetointegradorads4.dao.CategoriaDao;
import com.senac.projetointegradorads4.dao.Web_userDao;
import com.senac.projetointegradorads4.model.Categoria;
import com.senac.projetointegradorads4.model.Web_user;

import java.util.ArrayList;
import java.util.List;

public class AtvWebUserLista extends AppCompatActivity implements View.OnClickListener, AdapterView.OnItemClickListener {

    ListView lstCategorias;
    Button btnInserir;

    List<Web_user> listaCategorias = new ArrayList<>();
    ListAdapter listAdapter;
    int indice;
    Web_userDao web_userDao;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.atv_webuser_lista);

        btnInserir = findViewById(R.id.btnInserir);
        btnInserir.setOnClickListener(this);

        lstCategorias = findViewById(R.id.lstCategorias);
        lstCategorias.setOnItemClickListener(this);

        web_userDao = new Web_userDao(this);
    }

    private void atualizarLista(){
        listaCategorias = web_userDao.lista();
        listAdapter = new ArrayAdapter<Web_user>(this,android.R.layout.simple_list_item_1, listaCategorias);
        lstCategorias.setAdapter(listAdapter);
    }

    @Override
    protected void onResume() {
        super.onResume();
        atualizarLista();
    }

    @Override
    public void onClick(View v) {
        Web_user c = new Web_user();
        c.setLogin_id(0L);
        abrirCadastro("Inserir",c);
    }

    @Override
    public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
        indice = position;
        Web_user c = (Web_user) lstCategorias.getAdapter().getItem(position);
        abrirCadastro("Alterar", c);
    }

    private void abrirCadastro(String acao, Web_user c) {
        Intent telaCad = new Intent(this, AtvWebUserCadastro.class);
        Bundle extras = new Bundle();
        extras.putString("acao",acao);
        extras.putSerializable("obj",c);
        telaCad.putExtras(extras);
        startActivity(telaCad);
    }
}