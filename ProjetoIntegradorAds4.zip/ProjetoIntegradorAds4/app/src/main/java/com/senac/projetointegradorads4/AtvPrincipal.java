package com.senac.projetointegradorads4;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;

public class AtvPrincipal extends AppCompatActivity implements View.OnClickListener {

    ImageButton ibtCategoria;
    ImageButton ibtProduto;
    ImageButton btnCadCliente;
    ImageButton btnUser;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.atv_principal);

        ibtCategoria = findViewById(R.id.ibtCategoria);
        ibtCategoria.setOnClickListener(this);
        ibtProduto = findViewById(R.id.ibtProduto);
        ibtProduto.setOnClickListener(this);
        btnCadCliente = findViewById(R.id.btnCadCliente);
        btnCadCliente.setOnClickListener(this);

        btnUser = findViewById(R.id.btnUser);
        btnUser.setOnClickListener(this);

    }

    @Override
    public void onClick(View v) {
        if (v == ibtCategoria) {
            Intent telaCategoria = new Intent(this, AtvCategoriaLista.class);
            startActivity(telaCategoria);
        }
        else if (v == ibtProduto) {
            Intent telaProduto = new Intent(this, AtvProdutoLista.class);
            startActivity(telaProduto);
        }
        else if (v == btnCadCliente)
        {
            Intent telaCliente = new Intent(this, AtvClienteLista.class);
            startActivity(telaCliente);
        }
        else if( v == btnUser)
        {
            Intent telaUser = new Intent(this, AtvWebUserLista.class);
            startActivity(telaUser);
        }
    }
}