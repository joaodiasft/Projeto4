package com.senac.projetointegradorads4;

import android.os.Bundle;
import android.view.View;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.senac.projetointegradorads4.dao.ClienteDao;
import com.senac.projetointegradorads4.dao.Web_userDao;
import com.senac.projetointegradorads4.model.Cliente;
import com.senac.projetointegradorads4.model.Web_user;

import java.util.List;

public class AtvWebUserCadastro extends AppCompatActivity implements View.OnClickListener {

    EditText edtCodigo;
    EditText edtUsername;
    EditText edtSenha;

    Spinner spnCateg;

    Button btnGravar;
    Button btnExcluir;

    String acao;
    Web_user c;
    Web_userDao dao;

    List<Cliente> listaCliente;
    BaseAdapter baseAdapter;

    private void criarComponentes(){

        edtCodigo = findViewById(R.id.editCodigo);
        edtUsername = findViewById(R.id.editUsername);
        edtSenha = findViewById(R.id.editSenha);


        spnCateg = findViewById(R.id.spnCateg);

        btnGravar = findViewById(R.id.btnGravar);
        btnGravar.setOnClickListener(this);

        btnExcluir = findViewById(R.id.btnExcluir);
        btnExcluir.setOnClickListener(this);
        btnExcluir.setVisibility(acao.equals("Inserir") ? View.INVISIBLE : View.VISIBLE);


    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.atv_webuser_cadastro);

        acao = getIntent().getExtras().getString("acao");
        dao = new Web_userDao(this);


        criarComponentes();

        if(getIntent().getExtras().getSerializable("obj") != null){
            c = (Web_user) getIntent().getExtras().getSerializable("obj");



            edtCodigo.setText(String.valueOf(c.getLogin_id()));
            edtUsername.setText(c.getUsername());
            edtSenha.setText(String.valueOf(c.getSenha()));

        }
    }

    @Override
    public void onClick(View v) {
        if (v == btnGravar) {
            c.setUsername(edtUsername.getText().toString());
            c.setSenha(Integer.valueOf(edtSenha.getText().toString()));


            if(acao.equals("Inserir")){
                Long id = dao.inserir(c);
               String text = String.format(getString(R.string.webuser_inserido),c.getUsername(),id.toString());
                Toast.makeText(this,text,Toast.LENGTH_LONG).show();
            }else{
                long id = dao.alterar(c);
                String text = String.format(getString(R.string.webuser_alterado),c.getUsername());
                Toast.makeText(this,text,Toast.LENGTH_LONG).show();
            }
            finish();
        }
        else if (v == btnExcluir) {
            long id = dao.excluir(c);

            String text = String.format(getString(R.string.webuser_excluido),c.getUsername());
            Toast.makeText(this,text,Toast.LENGTH_LONG).show();
            finish();
        }
    }
}