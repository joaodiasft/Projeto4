package com.senac.projetointegradorads4.dao;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import com.senac.projetointegradorads4.model.Cliente;
import com.senac.projetointegradorads4.model.Endereco;

import java.util.ArrayList;
import java.util.List;

public class EnderecoDao {

    private final String TABELA = "endereco";
    private final String[] CAMPOS = {"id, logradouro, numero, complemento, bairro, cidade, estado, cep"};
    private Conexao conexao;
    private SQLiteDatabase banco;

    public EnderecoDao(Context context){
        conexao = new Conexao(context);
        banco = conexao.getWritableDatabase();
    }

    private ContentValues preencherValores(Endereco endereco){
        ContentValues values = new ContentValues();

        values.put("logradouro", endereco.getLogradouro());
        values.put("numero", endereco.getNumero());
        values.put("complemento", endereco.getComplemento());
        values.put("bairro", endereco.getBairro());
        values.put("cidade", endereco.getCidade());
        values.put("estado", endereco.getEstado());
        values.put("cep", endereco.getCep());

        return values;
    }

    public long inserir(Endereco endereco){
        ContentValues values = preencherValores(endereco);
        return banco.insert(TABELA,null,values);
    }

    public long alterer(Endereco endereco){
        ContentValues values = preencherValores(endereco);
        return banco.update(TABELA,values,"id = ?", new String[]{String.valueOf(endereco.getId())});
    }

    public long excluir(Endereco endereco){
        return banco.delete(TABELA,"id = ?",new String[]{String.valueOf(endereco.getId())});
    }

    public List<Endereco> lista(){
        Cursor c = banco.query(TABELA,CAMPOS,null,null,null,null,null);
        List<Endereco> lista = new ArrayList<>();
        while (c.moveToNext()){
            Endereco endereco = new Endereco();
            endereco.setId(c.getLong(0));
            endereco.setLogradouro(c.getString(1));
            endereco.setNumero(c.getInt(2));
            endereco.setComplemento(c.getString(3));
            endereco.setBairro(c.getString(4));
            endereco.setCidade(c.getString(5));
            endereco.setEstado(c.getString(6));
            endereco.setCep(c.getInt(7));

            lista.add(endereco);
        }
        return lista;
    }
}
