package com.senac.projetointegradorads4;

import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.senac.projetointegradorads4.dao.CategoriaDao;
import com.senac.projetointegradorads4.dao.ProdutoDao;
import com.senac.projetointegradorads4.model.Categoria;
import com.senac.projetointegradorads4.model.Produto;

import java.util.List;

public class AtvProdutoCadastro extends AppCompatActivity implements View.OnClickListener {

    EditText edtCodigo;
    EditText edtNome;
    EditText editCusto;
    EditText editPrecoVenda;
    EditText editUnidade;
    EditText editQuantidade;
    Spinner spnCateg;

    Button btnGravar;
    Button btnExcluir;

    String acao;
    Produto c;
    ProdutoDao dao;

    CategoriaDao categoriaDao;
    List<Categoria> listaCateg;
    BaseAdapter baseAdapter;

    private void criarComponentes(){

        edtCodigo = findViewById(R.id.editCodigo);
        edtNome = findViewById(R.id.editUsername);
        editCusto = findViewById(R.id.editSenha);
        editPrecoVenda = findViewById(R.id.editTelefone);
        editUnidade = findViewById(R.id.editEmail);
        editQuantidade = findViewById(R.id.editQuantidade);
        spnCateg = findViewById(R.id.spnCateg);

        btnGravar = findViewById(R.id.btnGravar);
        btnGravar.setOnClickListener(this);

        btnExcluir = findViewById(R.id.btnExcluir);
        btnExcluir.setOnClickListener(this);
        btnExcluir.setVisibility(acao.equals("Inserir") ? View.INVISIBLE : View.VISIBLE);


        categoriaDao = new CategoriaDao(this);
        listaCateg = categoriaDao.lista();
        baseAdapter = new ArrayAdapter<Categoria>(this,android.R.layout.simple_list_item_1, listaCateg);
        spnCateg.setAdapter(baseAdapter);
    }

    int retornarIndiceCategoria(long idCat) {
        int indice = 0;
        for (Categoria obj: listaCateg) {
            if (obj.getId() == idCat) {
                return indice;
            }
            indice++;
        }
        return 0;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.atv_produto_cadastro);

        acao = getIntent().getExtras().getString("acao");
        dao = new ProdutoDao(this);
        criarComponentes();

        if(getIntent().getExtras().getSerializable("obj") != null){
            c = (Produto) getIntent().getExtras().getSerializable("obj");
            edtCodigo.setText(String.valueOf(c.getId()));
            edtNome.setText(c.getNome());
            editCusto.setText(String.valueOf(c.getCusto()));
            editPrecoVenda.setText(String.valueOf(c.getPrecoVenda()));
            editQuantidade.setText(String.valueOf(c.getQuantidade()));
            editUnidade.setText(c.getUnidade());

            int ind = retornarIndiceCategoria(c.getCategoria().getId());
            spnCateg.setSelection(ind);
        }
    }

    @Override
    public void onClick(View v) {
        if (v == btnGravar) {
            c.setNome(edtNome.getText().toString());
            c.setQuantidade(Integer.valueOf(editQuantidade.getText().toString()));
            c.setUnidade(editUnidade.getText().toString());
            c.setPrecoVenda(Float.valueOf(editPrecoVenda.getText().toString()));
            c.setCusto(Float.valueOf(editCusto.getText().toString()));

            Categoria cat = (Categoria) spnCateg.getSelectedItem();
            c.setCategoria(cat);

            if(acao.equals("Inserir")){
                Long id = dao.inserir(c);
                String text = String.format(getString(R.string.produto_inserido),c.getNome(),id.toString());
                Toast.makeText(this,text,Toast.LENGTH_LONG).show();
            }else{
                long id = dao.alterer(c);
                String text = String.format(getString(R.string.produto_alterado),c.getNome());
                Toast.makeText(this,text,Toast.LENGTH_LONG).show();
            }
            finish();
        }
        else if (v == btnExcluir) {
            long id = dao.excluir(c);
            String text = String.format(getString(R.string.produto_excluido),c.getNome());
            Toast.makeText(this,text,Toast.LENGTH_LONG).show();
            finish();
        }
    }
}