package com.senac.projetointegradorads4.dao;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import com.senac.projetointegradorads4.model.Produto;

import java.util.ArrayList;
import java.util.List;

public class ProdutoDao {

    private final String TABELA = "produto";
    private final String[] CAMPOS = {"id, nome, custo, precoVenda, unidade, quantidade, id_categ"};
    private Conexao conexao;
    private SQLiteDatabase banco;

    public ProdutoDao(Context context){
        conexao = new Conexao(context);
        banco = conexao.getWritableDatabase();
    }

    private ContentValues preencherValores(Produto produto){
        ContentValues values = new ContentValues();

        values.put("nome", produto.getNome());
        values.put("custo", produto.getCusto());
        values.put("precoVenda", produto.getPrecoVenda());
        values.put("unidade", produto.getUnidade());
        values.put("quantidade", produto.getQuantidade());
        values.put("id_categ", produto.getCategoria().getId());

        return values;
    }

    public long inserir(Produto produto){
        ContentValues values = preencherValores(produto);
        return banco.insert(TABELA,null,values);
    }

    public long alterer(Produto produto){
        ContentValues values = preencherValores(produto);
        return banco.update(TABELA,values,"id = ?", new String[]{String.valueOf(produto.getId())});
    }

    public long excluir(Produto produto){
        return banco.delete(TABELA,"id = ?",new String[]{String.valueOf(produto.getId())});
    }

    public List<Produto> lista(){
        Cursor c = banco.query(TABELA,CAMPOS,null,null,null,null,null);
        List<Produto> lista = new ArrayList<>();
        while (c.moveToNext()){
            Produto produto = new Produto();
            produto.setId(c.getLong(0));
            produto.setNome(c.getString(1));
            produto.setCusto(c.getFloat(2));
            produto.setPrecoVenda(c.getFloat(3));
            produto.setUnidade(c.getString(4));
            produto.setQuantidade(c.getInt(5));
            produto.getCategoria().setId(c.getInt(6));
            lista.add(produto);
        }
        return lista;
    }
}
