package com.senac.projetointegradorads4;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListAdapter;
import android.widget.ListView;

import androidx.appcompat.app.AppCompatActivity;

import com.senac.projetointegradorads4.dao.ClienteDao;
import com.senac.projetointegradorads4.dao.ProdutoDao;
import com.senac.projetointegradorads4.model.Cliente;
import com.senac.projetointegradorads4.model.Produto;

import java.util.ArrayList;
import java.util.List;

public class AtvClienteLista extends AppCompatActivity implements View.OnClickListener, AdapterView.OnItemClickListener {

    ListView lstClientes;
    Button btnInserir;

    List<Cliente> listaClientes = new ArrayList<>();
    ListAdapter listAdapter;
    int indice;
    ClienteDao clienteDao;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.atv_cliente_lista);

        btnInserir = findViewById(R.id.btnInserir);
        btnInserir.setOnClickListener(this);

        lstClientes = findViewById(R.id.listClientes);
        lstClientes.setOnItemClickListener(this);

        clienteDao = new ClienteDao(this);
    }

    private void atualizarLista(){
        listaClientes = clienteDao.lista();
        listAdapter = new ArrayAdapter<Cliente>(this,android.R.layout.simple_list_item_1, listaClientes);
        lstClientes.setAdapter(listAdapter);
    }

    @Override
    protected void onResume() {
        super.onResume();
        atualizarLista();
    }

    @Override
    public void onClick(View v) {
        Cliente c = new Cliente();
        c.setId(0L);
        abrirCadastro("Inserir",c);
    }

    @Override
    public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
        indice = position;
        Cliente c = (Cliente) lstClientes.getAdapter().getItem(position);
        abrirCadastro("Alterar",c);
    }

    private void abrirCadastro(String acao, Cliente c) {
        Intent telaCad = new Intent(this, AtvClienteCadastro.class);
        Bundle extras = new Bundle();
        extras.putString("acao",acao);
        extras.putSerializable("obj",c);
        telaCad.putExtras(extras);
        startActivity(telaCad);
    }

}