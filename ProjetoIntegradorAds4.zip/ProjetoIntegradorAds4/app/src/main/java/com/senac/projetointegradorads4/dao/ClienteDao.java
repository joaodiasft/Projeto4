package com.senac.projetointegradorads4.dao;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import com.senac.projetointegradorads4.model.Cliente;
import com.senac.projetointegradorads4.model.Produto;

import java.util.ArrayList;
import java.util.List;

public class ClienteDao {

    private final String TABELA = "clientes";
    private final String[] CAMPOS = {"id, nome, cpf, telefone, email"};
    private Conexao conexao;
    private SQLiteDatabase banco;

    public ClienteDao(Context context){
        conexao = new Conexao(context);
        banco = conexao.getWritableDatabase();
    }

    private ContentValues preencherValores(Cliente cliente){
        ContentValues values = new ContentValues();

        values.put("nome", cliente.getNome());
        values.put("cpf", cliente.getCpf());
        values.put("telefone", cliente.getTelefone());
        values.put("email", cliente.getEmail());


        return values;
    }

    public long inserir(Cliente cliente){
        ContentValues values = preencherValores(cliente);
        return banco.insert(TABELA,null,values);
    }

    public long alterer(Cliente cliente){
        ContentValues values = preencherValores(cliente);
        return banco.update(TABELA,values,"id = ?", new String[]{String.valueOf(cliente.getId())});
    }

    public long excluir(Cliente cliente){
        return banco.delete(TABELA,"id = ?",new String[]{String.valueOf(cliente.getId())});
    }

    public List<Cliente> lista(){
        Cursor c = banco.query(TABELA,CAMPOS,null,null,null,null,null);
        List<Cliente> lista = new ArrayList<>();
        while (c.moveToNext()){
            Cliente cliente = new Cliente();
            cliente.setId(c.getLong(0));
            cliente.setNome(c.getString(1));
            cliente.setCpf(c.getString(2));
            cliente.setTelefone(c.getString(3));
            cliente.setEmail(c.getString(4));

            lista.add(cliente);
        }
        return lista;
    }
}
