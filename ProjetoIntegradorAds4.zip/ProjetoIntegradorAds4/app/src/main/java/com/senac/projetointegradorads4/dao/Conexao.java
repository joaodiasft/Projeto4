package com.senac.projetointegradorads4.dao;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class Conexao extends SQLiteOpenHelper {
    private static final String NAME = "banco.db";
    private static final int VERSION = 1;

    private static final String SQL_CREATE_CATEGORIA = "create table categoria ( " +
            " id integer primary key autoincrement, " +
            "nome varchar(50) " +
            ");";

    private static final String SQL_CREATE_PRODUTO = "create table produto ( " +
            " id integer primary key autoincrement, " +
            "nome varchar(50), " +
            "custo float, " +
            "precoVenda float, " +
            "unidade varchar(50), " +
            "quantidade integer, " +
            "id_categ integer, " +
            "constraint rel_categoria_produto foreign key (id_categ) references categoria(id) " +
            ");";

    private static final String SQL_CREATE_ENDERECO = "create table endereco ( " +
            " id integer primary key autoincrement, " +
            "logradouro varchar(50), " +
            "numero varchar(10), " +
            "complemento varchar(10), " +
            "bairro varchar(50), " +
            "cidade varchar(50), " +
            "estado varchar(50), " +
            "cep varchar(10) " +
            ");";

    private static final String SQL_CREATE_CLIENTES = "create table clientes ( " +
            " id integer primary key autoincrement, " +
            "nome varchar(50), " +
            "cpf varchar(13), " +
            "telefone varchar(15), " +
            "email varchar(50), " +
            "endereco varchar(60), " +
            "id_end interger, " +
            "constraint rel_endereco_cliente foreign key (id_end) references endereco(id) " +
            ");";

    private static final String SQL_CREATE_WEBUSER = "create table webuser ( " +
            " id integer primary key autoincrement, " +
            "senha interger, " +
            "estado varchar(10), " +
            "username varchar(30) " +
            ");";

    public Conexao(Context context){
        super(context,NAME,null,VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL(SQL_CREATE_CATEGORIA);
        db.execSQL(SQL_CREATE_PRODUTO);
        db.execSQL(SQL_CREATE_CLIENTES);
        db.execSQL(SQL_CREATE_ENDERECO);
        db.execSQL(SQL_CREATE_WEBUSER);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

    }
}
