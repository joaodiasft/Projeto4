package com.senac.projetointegradorads4;

import android.os.Bundle;
import android.view.View;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.senac.projetointegradorads4.dao.ClienteDao;
import com.senac.projetointegradorads4.model.Cliente;

import java.util.List;

public class AtvClienteCadastro extends AppCompatActivity implements View.OnClickListener {

    EditText edtCodigo;
    EditText edtNome;
    EditText editCPF;
    EditText editTelefone;
    EditText editEmail;



    Spinner spnCateg;

    Button btnGravar;
    Button btnExcluir;

    String acao;
    Cliente c;
    ClienteDao dao;

    List<Cliente> listaCliente;
    BaseAdapter baseAdapter;

    private void criarComponentes(){

        edtCodigo = findViewById(R.id.editCodigo);
        edtNome = findViewById(R.id.editUsername);
        editCPF = findViewById(R.id.editSenha);
        editTelefone = findViewById(R.id.editTelefone);
        editEmail = findViewById(R.id.editEmail);

        spnCateg = findViewById(R.id.spnCateg);

        btnGravar = findViewById(R.id.btnGravar);
        btnGravar.setOnClickListener(this);

        btnExcluir = findViewById(R.id.btnExcluir);
        btnExcluir.setOnClickListener(this);
        btnExcluir.setVisibility(acao.equals("Inserir") ? View.INVISIBLE : View.VISIBLE);


    }


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.atv_cliente_cadastro);

        acao = getIntent().getExtras().getString("acao");
        dao = new ClienteDao(this);


        criarComponentes();

        if(getIntent().getExtras().getSerializable("obj") != null){
            c = (Cliente) getIntent().getExtras().getSerializable("obj");



            edtCodigo.setText(String.valueOf(c.getId()));
            edtNome.setText(c.getNome());
            editCPF.setText(String.valueOf(c.getCpf()));
            editTelefone.setText(String.valueOf(c.getTelefone()));
            editEmail.setText(String.valueOf(c.getEmail()));

        }
    }

    @Override
    public void onClick(View v) {
        if (v == btnGravar) {
            c.setNome(edtNome.getText().toString());
            c.setCpf(editCPF.getText().toString());
            c.setTelefone(editTelefone.getText().toString());
            c.setEmail(editEmail.getText().toString());

            if(acao.equals("Inserir")){
                Long id = dao.inserir(c);
               String text = String.format(getString(R.string.cliente_inserido),c.getNome(),id.toString());
                Toast.makeText(this,text,Toast.LENGTH_LONG).show();
            }else{
                long id = dao.alterer(c);
                String text = String.format(getString(R.string.cliente_alterado),c.getNome());
                Toast.makeText(this,text,Toast.LENGTH_LONG).show();
            }
            finish();
        }
        else if (v == btnExcluir) {
            long id = dao.excluir(c);

            String text = String.format(getString(R.string.cliente_excluido),c.getNome());
            Toast.makeText(this,text,Toast.LENGTH_LONG).show();
            finish();
        }
    }
}